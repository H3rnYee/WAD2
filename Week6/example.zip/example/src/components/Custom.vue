<template>

    <h1>Goodbye World </h1>

    <!-- placeholder -->
     <p><slot></slot></p>
    <!-- <p> <slot name="slotA"></slot> </p>

    <button class="btn btn-primary">  <slot name="slotB"></slot> </button> -->
</template>

<style scoped>
h1 {
    color: red;
}
</style>