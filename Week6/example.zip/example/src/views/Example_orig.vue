<script setup>
import { ref, computed } from 'vue'

import CustomCard from '../components/CustomCard_orig.vue/index.js'

// const likeCount = ref(0)
// const dislikeCount = ref(0)

// function doLike() {

//   likeCount.value++

// }

// function doDisLike() {

//   dislikeCount.value++

// }

const cards = ref( [
  { title : "card1", msg : "hello world", img : "happy"},
  { title : "card2", msg : "goodbye world", img : "sad"},
  { title : "card3", msg : "7 hours of coding. Prof made me do it", img : "angry"},
] )

</script>

<template>

  <CustomCard v-for="card in cards" :msg="card.msg" :img-src=card.img > {{  card.title }} </CustomCard>


<!-- <div class="card" style="width: 18rem;">
  <img class="card-img-top" src="/happy.png" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary" @click="doLike">#Like {{ likeCount }}</a>
     <a href="#" class="btn btn-danger" @click="doDisLike">#DisLike {{ dislikeCount }}</a>
  </div>
</div> -->

<!-- <button class="btn btn-primary" @clikc="doLike">Like {{ likeCount }}</button> -->

</template>

<style scoped>
</style>