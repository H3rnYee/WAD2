<script setup>
import { ref, computed } from 'vue'

const likeCount = ref(0)
const dislikeCount = ref(0)

const props = defineProps( { 
    msg : "String",
    imgSrc : "String"
} )

function doLike() {

    likeCount.value++

}

function doDisLike() {

    dislikeCount.value++

}
</script>

<template>
    <div class="card w-50">
        <img class="card-img-top w-50" :src="'/'+imgSrc+'.png'" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title"> <slot> </slot> </h5>
            <p class="card-text">{{msg}}</p>
            <a href="#" class="btn btn-primary" @click="doLike">#Like {{ likeCount }}</a>
            <a href="#" class="btn btn-danger" @click="doDisLike">#DisLike {{ dislikeCount }}</a>
        </div>
    </div>
</template>